// Create the addNumbers function here.
function addNumbers() {
    var two = 2;
    var three = 3;

    var five = two + three;

    console.log(five);    
}

addNumbers();

// Create the stringConcat function here.
function stringConcat() {
    var taco = 'taco';
    var cat = 'cat';

    var tacoCat = taco + ' ' + cat;

    alert(tacoCat);
}

stringConcat();
