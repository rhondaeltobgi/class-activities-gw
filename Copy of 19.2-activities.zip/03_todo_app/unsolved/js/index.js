// Create event listener to enter items below

// Create event listener to delete items below

// Create event listener to toggle 
